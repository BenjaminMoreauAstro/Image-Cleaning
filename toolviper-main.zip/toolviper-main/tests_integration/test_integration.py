def test_imports():
    import toolviper
    import xradio
    import graphviper
    import astroviper

    assert True
